<footer>
			<div class="inner-footer">
				<div class="container">
					<div class="row">
						<div class="col-md-3">
							<div class="f-about">
								<h1>ABOUT </h1>
								<p class="mb20">Concept believes in your vision and is ready to actualise it.</p>
								<br>	
								<h2>Make a quote with us today</h2>
								<button type="button" name="" class="btn btn-danger">Make Quote</button>
								
							</div>
						</div>
						<div class="col-md-3">
							<div class="infos">
								<h1>Information</h1>
								<ul>
									<li><a href="#services">• Our Services</a></li>
									<li><a href="#about">• About Us</a></li>
									<li><a href="#">• Terms and Conditions</a></li>
									<li><a href="#">• Privacy Policy</a></li>
									<li><a href="#contact">• Contact Us</a></li>
									
								</ul>
							</div>
						</div>
						<div class="col-md-3">
							<div class="account">
								<h1>Specialties</h1>
								<ul>
									<li> IOS</a></li>
									<li> Java</a></li>
									<li> Web Design</a></li>
									<li> Android</a></li>
									<li> Graphic Design</a></li>
									<li> Data Recovery </li>
									<li> Cyber Security</li>
								</ul>
							</div>
						</div>
						<div class="col-md-3">
							<div class="gettouch">
								<h1>Get in Touch with us</h1>
								<p><i class="fa fa-home"></i> Kenya, PO Box 6200 Nairobi</p>
								<p><i class="fa fa-phone"></i> +254 796 829925</p>
								<p><i class="fa fa-phone"></i> +254 720 091625</p>
								<p class="mb20"><i class="fa fa-envelope"></i> concept101ke@gmail.com</p>
								<h1>FIND US ON</h1>
								<ul class="footer-socials">
									<li><a href="https://www.facebook.com/Concept-1968780766528321/s"><i class="fa fa-facebook"></i></a></li>
									<li><a href="https://twitter.com/?lang=en"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									<li><a href="#"><i class="fa fa-youtube"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			<div id="back-to-top">
	          <a href="#about">Back to Top</a>
	        </div>
			</div>
			<!-- end contanir & inner-footer -->
			<div class="container">
				<div class="last-div">
					<div class="row">
						<div class="copyright">
							© 2018 Concept Kenya ||<a href="#">Designed by Ginamu</a>
						</div>
						<!-- <div class="payment">
							<a href="#"><img src="upload/payments.png" alt=""></a>
						</div> -->
						<div class="clear"></div>
					</div>

				</div>
			</div>



	        
		</footer>